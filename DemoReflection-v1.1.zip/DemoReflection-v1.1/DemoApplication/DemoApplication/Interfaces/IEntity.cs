﻿
namespace DemoApplication.Interfaces
{
    public interface IEntity
    {
        int ID { get; set; }
        string GUID { get; set; }
    }
}
