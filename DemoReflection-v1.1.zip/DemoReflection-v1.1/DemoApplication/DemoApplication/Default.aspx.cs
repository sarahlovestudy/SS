﻿using System;
using System.Web.UI;

namespace DemoApplication
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //StudentRepository repo = new StudentRepository();
            //var data=repo.GetAll();
            //var data1 = repo.Add(new Entities.Student() { Age = 20.ToString(), Email = "cmdskfj", GUID = Guid.NewGuid().ToString(), Name = "Abhi" });
            //data = repo.GetAll();
        }
    }
}